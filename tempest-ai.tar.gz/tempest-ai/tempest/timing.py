"""
Video-Timing und Pixeltakt-Harmonische.

Der Pixeltakt bestimmt alles: Er ist die Rate, mit der Pixel über HDMI/TMDS
gesendet werden, und seine Harmonischen sind die Frequenzen, auf denen die
ungewollte Emanation abgestrahlt wird. Fuer 1080p60 gilt:

    pixel_clock = h_total * v_total * refresh
                = 2200 * 1125 * 60 = 148_500_000 Hz = 148.5 MHz

Die drei Frequenzen aus deinem Setup sind exakt die ersten drei Harmonischen:
    148.5 MHz (x1), 297 MHz (x2), 445.5 MHz (x3).
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class VideoTiming:
    name: str
    h_active: int
    v_active: int
    h_total: int      # inkl. Blanking
    v_total: int      # inkl. Blanking
    refresh: int      # Hz

    @property
    def pixel_clock(self) -> float:
        """Pixeltakt in Hz."""
        return self.h_total * self.v_total * self.refresh

    @property
    def samples_per_frame(self) -> int:
        """Komplexe Samples pro Vollbild bei einem Sample/Pixel."""
        return self.h_total * self.v_total

    def harmonic(self, n: int) -> float:
        """n-te Pixeltakt-Harmonische in Hz (n=1 -> Fundamentale)."""
        return n * self.pixel_clock


# CEA-861 Standard-Timings
PRESETS = {
    "1080p60": VideoTiming("1080p60", 1920, 1080, 2200, 1125, 60),
    "1080p30": VideoTiming("1080p30", 1920, 1080, 2200, 1125, 30),
    "1600x900@60": VideoTiming("1600x900@60", 1600, 900, 1800, 1000, 60),  # deep-tempest Referenz
    "720p60": VideoTiming("720p60", 1280, 720, 1650, 750, 60),
}


def get(name: str = "1080p60") -> VideoTiming:
    if name not in PRESETS:
        raise KeyError(f"Unbekanntes Timing {name!r}. Verfuegbar: {list(PRESETS)}")
    return PRESETS[name]


if __name__ == "__main__":
    t = get("1080p60")
    print(f"{t.name}: pixel_clock = {t.pixel_clock/1e6:.1f} MHz, "
          f"{t.samples_per_frame} Samples/Frame")
    for n in (1, 2, 3):
        print(f"  {n}. Harmonische: {t.harmonic(n)/1e6:.1f} MHz")
