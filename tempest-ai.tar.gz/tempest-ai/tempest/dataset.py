"""
Datensaetze fuer das Training.

SyntheticPairs : erzeugt Paare on-the-fly aus sauberen Bildern (Textscreenshots)
                 -> unbegrenzte, perfekt ausgerichtete Trainingsdaten. Startpunkt.
RealPairs      : lae dt vorbereitete (degradiert.npy, sauber.png)-Paare aus echten
                 Captures (nach Alignment via tempest.align). Fuer Fine-Tuning.

Beide liefern zufaellige Patches (Default 256x256) als:
    input  : 2 x P x P  (Real, Imag, normiert)
    target : 1 x P x P  (sauber, [0,1])
"""
from __future__ import annotations
import glob
import os
import numpy as np
import torch
from torch.utils.data import Dataset
from PIL import Image

from . import synth


def _load_gray01(path: str) -> np.ndarray:
    return np.asarray(Image.open(path).convert("L"), dtype=np.float32) / 255.0


def _rand_patch(h, w, p, rng):
    if h <= p or w <= p:
        return 0, 0
    return rng.integers(0, h - p), rng.integers(0, w - p)


class SyntheticPairs(Dataset):
    def __init__(self, clean_dir: str, patch: int = 256, length: int = 2000,
                 snr_range=(2.0, 12.0), seed: int = 0):
        self.paths = sorted(glob.glob(os.path.join(clean_dir, "*.png")) +
                            glob.glob(os.path.join(clean_dir, "*.jpg")))
        if not self.paths:
            raise FileNotFoundError(f"Keine Bilder in {clean_dir}")
        self.patch = patch
        self.length = length
        self.snr_range = snr_range
        self.rng = np.random.default_rng(seed)

    def __len__(self):
        return self.length

    def __getitem__(self, idx):
        p = self.patch
        img = _load_gray01(self.paths[self.rng.integers(len(self.paths))])
        h, w = img.shape
        y0, x0 = _rand_patch(h, w, p, self.rng)
        clean = img[y0:y0 + p, x0:x0 + p]
        if clean.shape != (p, p):  # kleines Bild -> hochskalieren
            clean = np.asarray(Image.fromarray((clean * 255).astype(np.uint8))
                               .resize((p, p)), np.float32) / 255.0
        snr = float(self.rng.uniform(*self.snr_range))
        deg = synth.degrade(clean, snr_db=snr, rng=self.rng)
        deg = synth.normalize_complex2(deg)
        x = torch.from_numpy(deg.transpose(2, 0, 1).copy())          # 2xPxP
        t = torch.from_numpy(clean[None].copy())                     # 1xPxP
        return x, t


class RealPairs(Dataset):
    """
    Erwartet ein Verzeichnis mit Paaren:
        <name>.npy   -> HxWx2 float32  (ausgerichtete, degradierte Emanation)
        <name>.png   -> HxW  sauberes Original (Ground Truth)
    Diese Paare erzeugst du mit scripts-Alignment aus echten Aaronia-Captures.
    """
    def __init__(self, pair_dir: str, patch: int = 256, length: int = 2000, seed: int = 0):
        self.npys = sorted(glob.glob(os.path.join(pair_dir, "*.npy")))
        if not self.npys:
            raise FileNotFoundError(f"Keine .npy-Paare in {pair_dir}")
        self.patch = patch
        self.length = length
        self.rng = np.random.default_rng(seed)

    def __len__(self):
        return self.length

    def __getitem__(self, idx):
        p = self.patch
        npy = self.npys[self.rng.integers(len(self.npys))]
        deg = np.load(npy)
        clean = _load_gray01(npy[:-4] + ".png")
        h, w = clean.shape
        y0, x0 = _rand_patch(h, w, p, self.rng)
        deg = synth.normalize_complex2(deg[y0:y0 + p, x0:x0 + p])
        clean = clean[y0:y0 + p, x0:x0 + p]
        x = torch.from_numpy(deg.transpose(2, 0, 1).copy())
        t = torch.from_numpy(clean[None].copy())
        return x, t
